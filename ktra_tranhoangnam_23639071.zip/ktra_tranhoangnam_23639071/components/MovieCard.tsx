import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

export type Movie = {
  id: string;
  title: string;
  genre: string;
  year: number;
  rating: number;
  poster: string;
  isShowing: boolean;
};

export type MovieCardProps = {
  movie: Movie;
  layout?: 'row' | 'tile';
  onSelect: (id: string) => void;
};

const MovieCard = ({ movie, layout = 'row', onSelect }: MovieCardProps) => {
  const isTile = layout === 'tile';

  return (
    <TouchableOpacity style={[styles.card, isTile && styles.cardTile]} onPress={() => onSelect(movie.id)}>
      <Image source={{ uri: movie.poster }} style={[styles.poster, isTile && styles.posterTile]} />
      {isTile && (
        <View style={styles.badge}>
          <Text style={styles.badgeText}>⭐ {movie.rating.toFixed(1)}</Text>
        </View>
      )}
      <View style={[styles.info, isTile && styles.infoTile]}>
        <Text style={styles.title} numberOfLines={isTile ? 1 : undefined}>{movie.title}</Text>
        {!isTile && (
          <>
            <Text style={styles.text}>{movie.genre}</Text>
            <Text style={styles.text}>{movie.year}</Text>
            <Text style={styles.text}>⭐ {movie.rating.toFixed(1)}</Text>
          </>
        )}
        <Text style={styles.status}>{movie.isShowing ? '✅' : '❌'}</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: { flexDirection: 'row', backgroundColor: '#fff', marginBottom: 10, borderRadius: 8, borderWidth: 1, borderColor: '#ccc', padding: 8 },
  cardTile: { flexDirection: 'column', flex: 1, margin: 5 },
  poster: { width: 70, height: 100, borderRadius: 4 },
  posterTile: { width: '100%', aspectRatio: 2 / 3 },
  badge: { position: 'absolute', top: 10, right: 10, backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  badgeText: { color: '#fff', fontSize: 12 },
  info: { flex: 1, marginLeft: 10, justifyContent: 'center' },
  infoTile: { marginLeft: 0, marginTop: 6 },
  title: { fontSize: 16, fontWeight: 'bold' },
  text: { fontSize: 14, color: '#555', marginTop: 2 },
  status: { fontSize: 14, marginTop: 4 }
});

export default React.memo(MovieCard);